require 'test_helper'

module Recommender
  class RecommendTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end

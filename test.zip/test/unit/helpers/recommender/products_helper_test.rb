require 'test_helper'

module Recommender
  class ProductsHelperTest < ActionView::TestCase
  end
end

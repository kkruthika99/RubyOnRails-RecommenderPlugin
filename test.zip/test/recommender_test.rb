require 'test_helper'

class RecommenderTest < ActiveSupport::TestCase
  test "truth" do
    assert_kind_of Module, Recommender
  end
end

require 'test_helper'

module Recommender
  class ResourcesHelperTest < ActionView::TestCase
  end
end

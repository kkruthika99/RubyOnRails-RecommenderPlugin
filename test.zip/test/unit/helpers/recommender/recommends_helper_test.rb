require 'test_helper'

module Recommender
  class RecommendsHelperTest < ActionView::TestCase
  end
end
